package polimorfismo;

public class SimuladorVeiculo {

    void simular(Veiculo veiculo) {
        System.out.println(veiculo.toString());
    }
}
