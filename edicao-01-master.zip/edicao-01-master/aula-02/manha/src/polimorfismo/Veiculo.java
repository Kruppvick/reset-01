package polimorfismo;

class Veiculo {

    String nome;

    public Veiculo(String nome) {
        this.nome = nome;
    }

    public String toString() {
        return "Veículo: " + this.nome;
    }

}