package heranca;

public class App {

    public static void main(String[] args) {

        Submarino sub = new Submarino("Sub", 10.5);
    }
}
