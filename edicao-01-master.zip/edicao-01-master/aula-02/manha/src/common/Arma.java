package common;

public class Arma {

    String nome;

    double poderAtaque;

    public Arma(String nome, double poderAtaque) {
        this.nome = nome;
        this.poderAtaque = poderAtaque;
    }
}
