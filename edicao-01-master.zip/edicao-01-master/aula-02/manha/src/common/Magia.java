package common;

public class Magia {

    String nome;

    double poderAtaque;

    double custoMana;

    public Magia(String nome, double poderAtaque, double custoMana) {
        this.nome = nome;
        this.poderAtaque = poderAtaque;
        this.custoMana = custoMana;
    }
}
