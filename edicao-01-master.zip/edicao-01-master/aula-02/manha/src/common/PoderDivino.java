package common;

public class PoderDivino {

    String nome;

    double poderAtaque;

    double custoFe;

    public PoderDivino(String nome, double poderAtaque, double custoFe) {
        this.nome = nome;
        this.poderAtaque = poderAtaque;
        this.custoFe = custoFe;
    }
}
