package rpgpolimorfico;

public class Guerreiro extends HomemDeArmas {

    public Guerreiro(final String nome, final double vida, final double ataque, final double defesa) {
        super(nome, vida, ataque, defesa);
    }

}
