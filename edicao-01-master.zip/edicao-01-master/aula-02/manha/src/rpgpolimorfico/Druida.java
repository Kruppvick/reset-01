package rpgpolimorfico;

public class Druida extends Sacerdote {

    public Druida(final String nome, final double vida, final double ataque, final double defesa, final int fe) {
        super(nome, vida, ataque, defesa, fe);
    }
}
