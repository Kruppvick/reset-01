package rpgpolimorfico;

public class Mago extends Arcano {

    public Mago(final String nome, final double vida, final double ataque, final double defesa, final int mana) {
        super(nome, vida, ataque, defesa, mana);
    }

}
