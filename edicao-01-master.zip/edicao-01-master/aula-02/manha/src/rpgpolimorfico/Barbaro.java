package rpgpolimorfico;

public class Barbaro extends HomemDeArmas {


    public Barbaro(final String nome, final double vida, final double ataque, final double defesa) {
        super(nome, vida, ataque, defesa);
    }

}
