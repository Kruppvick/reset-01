package rpgpolimorfico;

public class Clerigo extends Sacerdote {

    public Clerigo(final String nome, final double vida, final double ataque, final double defesa, final int fe) {
        super(nome, vida, ataque, defesa, fe);
    }
}
