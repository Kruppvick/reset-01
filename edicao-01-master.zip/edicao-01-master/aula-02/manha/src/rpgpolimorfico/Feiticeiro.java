package rpgpolimorfico;

public class Feiticeiro extends Arcano {

    public Feiticeiro(final String nome, final double vida, final double ataque, final double defesa, final int mana) {
        super(nome, vida, ataque, defesa, mana);
    }
}
