package rpgpolimorfico;

public class Arqueiro extends HomemDeArmas {

    public Arqueiro(final String nome, final double vida, final double ataque, final double defesa) {
        super(nome, vida, ataque, defesa);
    }

}
