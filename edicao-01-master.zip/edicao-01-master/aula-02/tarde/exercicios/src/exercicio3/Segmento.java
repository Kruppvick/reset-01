package exercicio3;

public enum Segmento {

    ALIMENTACAO, LIMPEZA, HIGIENE;

}
