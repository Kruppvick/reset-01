package exercicio1;

public class Aluno {

    private final String nome;

    public Aluno(String nome) {
        this.nome = nome;
    }

    void obterNota() {

    }

    private void montarCola() {

    }

    public String getNome() {
        return nome;
    }
}
