package exercicio1;

public class Turma {

    public void obterNome() {

    }

    public void obterQuantidadeAlunos() {

    }

}
