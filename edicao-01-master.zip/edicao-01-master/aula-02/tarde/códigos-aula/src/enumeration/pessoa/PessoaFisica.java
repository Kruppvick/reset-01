package enumeration.solucao.pessoa;

public class PessoaFisica extends Pessoa {

    public PessoaFisica(String nome) {
        super(TipoPessoa.PESSOA_FISICA, nome);
    }
}
