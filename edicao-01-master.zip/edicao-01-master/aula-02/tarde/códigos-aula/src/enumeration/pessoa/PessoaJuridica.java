package enumeration.solucao.pessoa;

public class PessoaJuridica extends Pessoa {

    public PessoaJuridica(String nome) {
        super(TipoPessoa.PESSOA_JURIDICA, nome);
    }

}
