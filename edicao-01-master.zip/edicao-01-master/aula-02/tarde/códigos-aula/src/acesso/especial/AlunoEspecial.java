package acesso.solucao.especial;

import acesso.solucao.aluno.Aluno;
import acesso.solucao.turma.Turma;

public class AlunoEspecial extends Aluno {

    public AlunoEspecial(Turma turma, String nome) {
        super(turma, nome);
    }

}
