# Aula 01 - 07/03

## Manhã

- Apresentação
- Dinâmica em grupo
- Setup das máquinas
- Sobre o treinamento
- Instalação das ferramentas
- Git básico
- Hello World Java

## Tarde

- Variáveis
- Tipos de dados
- Operadores
- Orientação a objetos
- Exercícios

# Aula 02 - 14/03

## Manhã

- Revisão de dúvidas
- Modificadores de fluxo de execução
- Enumeradores
- Coleções
- Data e Hora
- Exercícios

## Tarde

- Tratamento de exceções
- Herança e Polimorfismo
- Modificadores de Acesso
- Exercícios

# Aula 03 - 21/03

## Manhã

- Revisão de dúvidas
- Arquitetura cliente-servidor
- HTTP
- REST
- JSON
- Postman
- Exercícios
- Projeto: Tinder Evolution
- Choro

## Tarde

- Frameworks
- Spring e Spring Boot
- Hello World Spring Web
- Packages
- Controllers
- Services
- Repositories
- Projeto

# Aula 04 - 28/03

## Manhã

- Revisão de dúvidas
- Banco de dados
- Exercícios

## Tarde

- Spring Data
- Entities
- Relacionamentos
- Repository
- Projeto
- Encerramento
