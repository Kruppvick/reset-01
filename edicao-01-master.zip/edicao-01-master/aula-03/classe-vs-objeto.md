### Classe vs Objeto

Classe é uma especificação, uma "planta", que agrupa características/estados (atributos) e comportamentos (métodos).
O objeto é uma instância desta classe, algo fisico, algo "paupável" e presente na memória do computador.

Classe -> planta
Objeto -> Casa
