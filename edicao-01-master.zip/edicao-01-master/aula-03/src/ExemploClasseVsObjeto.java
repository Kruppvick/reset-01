import calculadorapagamentos.Pessoa;

public class ExemploClasseVsObjeto {

	public static void main(String[] args) {
		Pessoa leonardo = new Pessoa("Leonardo", 180, 22, 'M');
		Pessoa neto = new Pessoa("Neto", 250, 18, 'M');
		Pessoa robeta = new Pessoa("Robeta", 150, 60, 'M');



	}
}
