public class PoderDivino {

    String nome;

    double poderAtaque;

    double custoFe;

    PoderDivino(String nome, double poderAtaque, double custoFe) {
        this.nome = nome;
        this.poderAtaque = poderAtaque;
        this.custoFe = custoFe;
    }
}
