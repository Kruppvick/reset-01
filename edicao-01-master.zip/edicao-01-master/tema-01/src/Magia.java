public class Magia {

    String nome;

    double poderAtaque;

    double custoMana;

    Magia(String nome, double poderAtaque, double custoMana) {
        this.nome = nome;
        this.poderAtaque = poderAtaque;
        this.custoMana = custoMana;
    }
}
