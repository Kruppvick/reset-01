public class Arma {

    String nome;

    double poderAtaque;

    Arma(String nome, double poderAtaque) {
        this.nome = nome;
        this.poderAtaque = poderAtaque;
    }
}
